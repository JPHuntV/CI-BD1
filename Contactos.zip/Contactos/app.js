const express = require('express');
var router = express.Router();
const bodyParser = require('body-Parser');
const path = require('path');
const NodeCouchDB = require('node-couchdb');

//Establecer conexion con couch
const couch = new NodeCouchDB({
	auth:{
		user:'admin',
		password: '1234'
	}
});

//ver todas las dbs
couch.listDatabases().then(function(dbs){
	console.log(dbs);//imprime en consola
});

//ejecutar una vista
const dbName = 'contactos';
const viewUrl = '_design/getContactos/_view/all';
const app = express();


app.set('view engine', 'ejs');
app.set('views',path.join(__dirname,'views'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: false}));
var sname = "";
app.get('/',function(req,res){
	
	couch.get(dbName,viewUrl).then(
		function(data,headers,status){
			console.log(data.data.rows);
			console.log(sname);
			res.render('index',{
				contactos:data.data.rows,
				name: sname

			});
		},
		function(err){
			res.send(err);
		});
});

app.post('/contacto/search',function(req,res){
	sname = req.body.name;
	res.redirect('/');
});

app.get('/Contacto',function(req,res){
	couch.get(dbName,viewUrl).then(
		function(data,headers,status){
			console.log(data.data.rows);
			res.render('Contacto',{
				contactos:data.data.rows,
				rev: req.query.rev,
				id: req.query.id

			});
		},
		function(err){
			res.send(err);
		});
	
});

app.get('/Agregar',function(req,res){
	res.render('Agregar');
	
});
//agregar contacto


app.post('/contacto/add', function(req, res){
	const nombre =req.body.nombre;
	const apellidos =req.body.apellidos;
	const telefono1 =req.body.telefono1;
	const telefono2 =req.body.telefono2;
	const correo =req.body.correo;
	const profesion =req.body.profesion;

	couch.uniqid().then(function(ids){
		const id = ids[0];
		
		couch.insert(dbName,{
			_id: id,
			nombre: nombre,
			apellidos: apellidos,
			telefono1: telefono1,
			telefono2: telefono2,
			correo: correo,
			profesion: profesion
		}).then(
				function(data, headers, status){
					res.redirect('/');
				},
				function(err){
					res.send(err);
				}
			);
	});

});

app.post('/contacto/delete',function(req,res){
	const id = req.body.id;
	const rev = req.body.rev;

	couch.del(dbName, id, rev).then(
		function(data, headers, status){
			res.redirect('/');
		},
		function(err){
				res.send(err);
		});
});

//actualizar contacto


app.get('/Actualizar',function(req,res){
	couch.get(dbName,viewUrl).then(
		function(data,headers,status){
			console.log(data.data.rows);
			res.render('Actualizar',{
				contactos:data.data.rows,
				rev: req.query.rev,
				id: req.query.id

			});
		},
		function(err){
			res.send(err);
		});
	
});
app.post('/contacto/update', function(req, res){
	const nombre =req.body.nombre;
	const apellidos =req.body.apellidos;
	const telefono1 =req.body.telefono1;
	const telefono2 =req.body.telefono2;
	const correo =req.body.correo;
	const profesion =req.body.profesion;
	const id = req.body.id;
	const rev = req.body.rev;
	
	couch.update(dbName,{
		_id: id,
		_rev: rev,
		nombre: nombre,
		apellidos: apellidos,
		telefono1: telefono1,
		telefono2: telefono2,
		correo: correo,
		profesion: profesion
	}).then(
			function(data, headers, status){
				res.redirect('/');
			},
			function(err){
				res.send(err);
			}
		);
});



app.listen(3000, function(){
	console.log('Server started on port 3000');
});