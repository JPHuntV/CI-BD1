 
     <script src="\Contactos\views\js\bootstrap.min.js"></script>
     <script src="\Contactos\views\js\moment.min.js" type="text/javascript"></script>
    

</body>
</html>